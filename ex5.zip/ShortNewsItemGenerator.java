public class ShortNewsItemGenerator implements NewsItemGenerator {
    @Override
    public NewsItem publish(String name, String mssg) {
        NewsItem newsItem=null;
        NewsDetails newsDetails=new ShortNewsDetails();
        if(name.equals("skating")){
            newsItem=new SkatingNews(newsDetails);

        }
        else if(name.equals("ski")){
            newsItem= new SkiNews(newsDetails);

        }
        else if (name.equals("hockey")){
            newsItem= new HockeyNews(newsDetails);

        }
        else if(name.equals("bobsleigh")){
            newsItem= new BobsleighNews(newsDetails);

        }
        else {
            System.out.println("ERROR:invalid news item" );
            return null;
        }
        newsItem.setName(name);
        newsItem.setMssg(mssg);

        newsItem.preparing();
        newsItem.editing();
        newsItem.finalizing();
        return newsItem;
    }


}
