public class SummaryGenerator {
}
