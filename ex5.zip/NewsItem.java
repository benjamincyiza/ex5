import java.util.ArrayList;

public abstract class NewsItem {
    String name;
    String mssg;
    ArrayList<String> language=new ArrayList<>();

    TitleGenerator tg;
    FederationGenerator fg;
    SummaryGenerator sg;

    void setName(String name) {
        this.name = name;
    }
    void setMssg(String m){mssg=m;}
    String getName() {
        return name;
    }
    String getMssg(){return mssg;}

    public abstract void preparing();
    public abstract NewsItem addTranslation(ArrayList<String> lang);

    public void editing(){
        System.out.println("Editing this news item ");
    }
    public void finalizing(){
        System.out.println("Finalizing this new item");
    }

    public String toString() {
       StringBuilder out= new StringBuilder(name + " news item\n" + "title generated for " + mssg + " \n" +
               "federation abbreviation generated for " + mssg + "\n" +
               "short summary generated for " + mssg + "\n ");
       for(String lang:language){
           out.append("was translated to ").append(lang).append("\n ");
       }
       return out.toString();
    }

}

