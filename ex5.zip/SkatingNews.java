import java.util.ArrayList;

public class SkatingNews extends NewsItem{
    NewsDetails newsDetails;
    public SkatingNews(NewsDetails d){
        newsDetails=d;
    }
    @Override
    public void preparing() {
        System.out.println("preparing "+name+" news");
        tg= newsDetails.generateTitle();
        fg=newsDetails.generateFederation();
        sg=newsDetails.generateSummary();
    }

    @Override
    public NewsItem addTranslation(ArrayList<String> lang) {
        language.addAll(lang);
        return this;
    }


}
