public class ShortNewsFederationGenerator extends FederationGenerator{
}
