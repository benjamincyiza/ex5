public class LongNewsFederationGenerator extends FederationGenerator{
}
