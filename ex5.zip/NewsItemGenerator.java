public interface NewsItemGenerator {
    public NewsItem publish(String name,String mssg);
}
