public class LongNewsDetails implements NewsDetails{
    @Override
    public TitleGenerator generateTitle() {
        return new LongNewsTitleGenerator();
    }

    @Override
    public FederationGenerator generateFederation() {
        return new LongNewsFederationGenerator();
    }

    @Override
    public SummaryGenerator generateSummary() {
        return new LongNewsSummaryGenerator();
    }
}
