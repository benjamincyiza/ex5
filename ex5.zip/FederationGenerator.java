public abstract  class FederationGenerator {
}
