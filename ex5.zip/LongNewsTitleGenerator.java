public class LongNewsTitleGenerator extends TitleGenerator{
}
