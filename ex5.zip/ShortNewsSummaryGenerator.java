public class ShortNewsSummaryGenerator extends SummaryGenerator{
}
