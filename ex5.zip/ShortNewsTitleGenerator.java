public class ShortNewsTitleGenerator extends TitleGenerator{

}
