public class ShortNewsDetails implements NewsDetails{
    @Override
    public TitleGenerator generateTitle() {
        return new ShortNewsTitleGenerator();
    }

    @Override
    public FederationGenerator generateFederation() {
        return new ShortNewsFederationGenerator();
    }

    @Override
    public SummaryGenerator generateSummary() {
        return new ShortNewsSummaryGenerator();
    }
}
