public class LongNewsSummaryGenerator extends  SummaryGenerator{
}
