import java.util.ArrayList;

public class SkiNews extends NewsItem {

    NewsDetails newsDetails;
    public SkiNews(NewsDetails d){
        newsDetails=d;
    }
    @Override
    public void preparing() {
        System.out.println("preparing "+name+" news");
        tg= newsDetails.generateTitle();
        fg=newsDetails.generateFederation();
        sg=newsDetails.generateSummary();
    }

    public NewsItem addTranslation(ArrayList<String> lang) {
        language=lang;
        return this;
    }

}
