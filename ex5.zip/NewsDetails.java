public interface NewsDetails {
    public TitleGenerator generateTitle();
    public  FederationGenerator generateFederation();
    public SummaryGenerator generateSummary();

}
