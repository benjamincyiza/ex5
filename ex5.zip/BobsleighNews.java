import java.util.ArrayList;

public class BobsleighNews extends NewsItem{

    NewsDetails newsDetails;
    public BobsleighNews(NewsDetails d){
        newsDetails=d;
    }
    @Override
    public void preparing() {
        System.out.println("preparing "+name+" news");
        tg= newsDetails.generateTitle();
        fg=newsDetails.generateFederation();
        sg=newsDetails.generateSummary();
    }
    public NewsItem addTranslation(ArrayList<String> lang) {
        language=lang;
        return this;
    }
}
